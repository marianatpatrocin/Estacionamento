const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const connection = require('./db_config.js');

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors())
app.use(bodyParser.json());
app.listen(port, () => console.log(`Rodando na porta${port}`));

app.post('/carros', (request, response) => {

    let params = [
        request.body.placa,
        request.body.modelo,
        request.body.cor
    ]

    let query = "INSERT INTO carros (placa, modelo, cor) VALUES (?, ?, ?);"
    connection.query(query, params, (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar carro",
                data: err
            });
        } else {
            return response.status(201).json({
                success: true,
                message: "Carro cadastrado com sucesso",
                data: results
            });
        }
    });
});

app.get('/carros/listar', (request, response) => {
    let query = "SELECT * FROM carros";
    connection.query(query, (err, results) => {
        if (results) {
            response.status(201).json({
                success: true,
                message: "Sucesso",
                data: results
            });
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                });
        }
    });
});

app.put('/carros/editar/:id', (request, response) => {
    let params = Array(
        request.body.placa,
        request.body.modelo,
        request.body.cor,
        parseInt(request.params.id)
    )

    let query = "UPDATE carros SET placa = ?, modelo = ?, cor = ? WHERE id = ?;";
    connection.query(query, params, (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao editar carro",
                data: err
            });
        } else {
            return response.status(200).json({
                success: true,
                message: "Carro atualizado com sucesso",
                data: results
            });
        }
    });
});

app.delete('/carros/deletar/:id', (request, response) => {
    let query = "DELETE FROM carros WHERE id = ?";
    connection.query(query, [request.params.id], (err, results) => {
        if (err) {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Erro ao excluir carro",
                    error: err
                });
        } else {
            if (results.affectedRows > 0) {
                response.status(200).json({
                    success: true,
                    message: "Carro deletado",
                    data: results
                });
            } else {
                response.status(404).json({
                    success: false,
                    message: "Carro não encontrado"
                });
            }
        }
    });
});