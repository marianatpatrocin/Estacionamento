async function carregarCarros() {
    const response = await fetch("http://localhost:3001/carros/listar");
    const carros = await response.json();    
    const tabela = document.querySelector('tbody')
    tabela.innerHTML = "";
    carros.data.forEach(carro => {
        const row = document.createElement("tr");
        row.innerHTML = `
                <td>${carro.placa}</td>
                <td>${carro.modelo}</td>
                <td>${carro.cor}</td>
                <td>
                    <button onclick="editarCarro(${carro.id}, '${carro.placa}', '${carro.modelo}', '${carro.cor}')">Editar</button>
                    <button onclick="deletarCarro(${carro.id})">Excluir</button>
                </td>
            `;
        tabela.appendChild(row);
    });
}

carregarCarros();

const API_URL = "http://localhost:3001/carros";

async function deletarCarro(id) {
    if (confirm("Tem certeza que deseja excluir este carro?")) {
        await fetch(`${API_URL}/${id}`, { method: "DELETE" });
        alert("Carro excluído com sucesso!");
        window.location.reload();
    }
}

async function editarCarro(id, placa, modelo, cor) {
    const novaPlaca = prompt("Nova placa:", placa);
    const novoModelo = prompt("Novo modelo:", modelo);
    const novaCor = prompt("Nova cor:", cor);

    if (novaPlaca && novoModelo && novaCor) {
        const response = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ placa: novaPlaca, modelo: novoModelo, cor: novaCor })
        });
        if (response.ok) {
            alert("Carro atualizado com sucesso!");
            window.location.reload();
        } else {
            alert("Erro ao atualizar o carro!");
        }
    }
}


// async function deletarCarro(id) {
//     if (confirm("Tem certeza que deseja excluir este carro?")) {
//         await fetch(`http://localhost:3001/carros/${id}`, { method: "DELETE" });
//         alert("Carro excluído com sucesso!");
//         window.location.reload();
//     }
// }
 
// async function editarCarro(id, placa, modelo, cor) {
//     const novaPlaca = prompt("Nova placa:", placa);
//     const novoModelo = prompt("Novo modelo:", modelo);
//     const novaCor = prompt("Nova cor:", cor);
 
//     if (novaPlaca && novoModelo && novaCor) {
//         const response = await fetch(`http://localhost:3001/carros/${id}`, {
//             method: "PUT",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify({ placa: novaPlaca, modelo: novoModelo, cor: novaCor })
//         });
//         if (response.ok) {
//             alert("Carro atualizado com sucesso!");
//             window.location.reload();
//         }
//     }
// }