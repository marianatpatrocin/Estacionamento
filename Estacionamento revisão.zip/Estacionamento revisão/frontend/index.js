document.getElementById("formulario").addEventListener("submit", async function (event) {
    event.preventDefault();

    const placa = document.getElementById('placa').value;
    const modelo = document.getElementById('modelo').value;
    const cor = document.getElementById('cor').value;

    const data = { placa, modelo, cor }

    try {
        const response = await fetch('http://localhost:3001/carros', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) {
            throw new Error("Erro na requisição: " + response.status);
        }

        const result = await response.json();

        if (response.ok) {
            alert("Carro cadastrado com sucesso!");
            window.location.href = "listagem.html";
        } else {
            alert("Erro: " + result.message);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao tentar cadastrar carro. Verifique se o servidor está rodando.');
    }
});